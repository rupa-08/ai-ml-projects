# mask-detection-dataset > 2025-06-15 11:47pm
https://universe.roboflow.com/yolo-piv4k/mask-detection-dataset-eizwe

Provided by a Roboflow user
License: CC BY 4.0

